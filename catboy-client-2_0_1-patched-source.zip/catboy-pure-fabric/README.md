# Catboy Client 2.0.1 (Pure Fabric)

Standalone client-side Fabric mod for Minecraft 1.21.11. Meteor Client is not required.

## Requirements
- Minecraft 1.21.11
- Java 21+
- Fabric Loader 0.19.3+
- Fabric API for Minecraft 1.21.11

## Controls
- Right Shift: open Catboy Click GUI
- Click the search field and type to filter modules
- Click a module row to toggle it
- Mouse wheel: scroll the module list
- Escape: close the GUI
- Accent, Glow, Opacity, and HUD buttons cycle through available settings

Settings and module toggles are saved to `config/catboy-client.properties`.

## Build
Run `gradle build` from this folder (or `./gradlew build` if you add a Gradle wrapper). The mod JAR is written to `build/libs/`.

This source archive has not been compiled or tested in a live Minecraft instance in this environment. Module entries other than the Brand, FPS, and Coordinates HUD are currently UI toggles/placeholders; they do not claim to implement combat automation or chunk scanning.
